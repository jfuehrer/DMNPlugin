#!/bin/bash

<<<<<<< HEAD
# Script to compile and package the DMN plugin

# Create necessary directories
mkdir -p build/com/example/dmn/plugin
mkdir -p build/com/example/dmn/stereotype
mkdir -p build/com/example/dmn/ui
mkdir -p build/com/example/dmn/decisiontable
mkdir -p build/com/example/dmn/resources/icons
mkdir -p lib

# Compile Java sources
echo "Compiling Java sources..."
javac -d build com/example/dmn/plugin/*.java com/example/dmn/stereotype/*.java com/example/dmn/ui/*.java com/example/dmn/decisiontable/*.java

# Copy resources
echo "Copying resources..."
cp -r com/example/dmn/resources/* build/com/example/dmn/resources/
=======
# Script to compile and package the DMN plugin for Magic Systems of Systems Architect 2022x
# Note: This script requires the MagicDraw/Magic Systems of Systems Architect JAR files
# which should be located in a directory specified by $MAGICSYSTEMS_HOME

# Check if MAGICSYSTEMS_HOME is set
if [ -z "$MAGICSYSTEMS_HOME" ]; then
  echo "Error: MAGICSYSTEMS_HOME environment variable not set."
  echo "Please set it to point to your Magic Systems of Systems Architect installation directory."
  exit 1
fi

# Create necessary directories
mkdir -p build/com/example/dmn
mkdir -p lib

# Gather all Java source files
echo "Gathering source files..."
find com -name "*.java" > sources.txt

# Compile Java sources
echo "Compiling Java sources..."
javac -d build -classpath "$MAGICSYSTEMS_HOME/lib/*:$MAGICSYSTEMS_HOME/plugins/*" @sources.txt

if [ $? -ne 0 ]; then
  echo "Compilation failed!"
  exit 1
fi

# Copy resources
echo "Copying resources..."
cp -r com/example/dmn/resources build/com/example/dmn/
>>>>>>> 8b85c5523f88961b2ad4610b2afe9f984215ddb2

# Create JAR file
echo "Creating plugin JAR..."
cd build
jar cf ../lib/dmn-plugin.jar com
cd ..

<<<<<<< HEAD
# Create distribution directories
mkdir -p dist/DMN_Plugin

# Copy plugin files
echo "Creating distribution package..."
cp descriptor.xml dist/DMN_Plugin/
cp plugin.xml dist/DMN_Plugin/
cp -r lib dist/DMN_Plugin/
cp README.md dist/DMN_Plugin/
=======
# Create distribution package
echo "Creating distribution package..."
mkdir -p dist/DMN_Plugin
cp -r plugin.xml lib README.md dist/DMN_Plugin/
>>>>>>> 8b85c5523f88961b2ad4610b2afe9f984215ddb2

# Create ZIP archive
echo "Creating ZIP archive..."
cd dist
<<<<<<< HEAD
zip -r DMN_Plugin.zip DMN_Plugin/*
cd ..

echo "Build completed successfully!"
echo "The plugin package is available at dist/DMN_Plugin.zip"
=======
zip -r DMN_Plugin.zip DMN_Plugin
cd ..

echo "Build completed successfully!"
echo "The plugin package is available at: dist/DMN_Plugin.zip"
>>>>>>> 8b85c5523f88961b2ad4610b2afe9f984215ddb2
