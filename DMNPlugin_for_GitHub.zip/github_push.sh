#!/bin/bash

# This script pushes code to GitHub using a stored token
# It uses the GITHUB_TOKEN environment variable

if [ -z "$GITHUB_TOKEN" ]; then
  echo "Error: GITHUB_TOKEN environment variable not set"
  echo "Please set up your GitHub token as a secret using 'ask_secrets' tool"
  exit 1
fi

# Configure Git (replace with your actual information)
read -p "Enter your GitHub username: " username
read -p "Enter your email: " email
git config --global user.name "$username"
git config --global user.email "$email"

# Initialize Git repository if not already initialized
if [ ! -d .git ]; then
  echo "Initializing Git repository..."
  git init
fi

# Add the remote repository with token included in URL
echo "Setting up remote repository..."
git remote remove origin 2>/dev/null
git remote add origin "https://$username:$GITHUB_TOKEN@github.com/jfuehrer/DMNPlugin.git"

# Add all files
echo "Adding files to Git..."
git add .

# Commit changes
echo "Committing changes..."
read -p "Enter commit message: " message
git commit -m "$message"

# Push to GitHub
echo "Pushing to GitHub..."
git push -u origin main

echo "Process completed. Check your GitHub repository at https://github.com/jfuehrer/DMNPlugin"