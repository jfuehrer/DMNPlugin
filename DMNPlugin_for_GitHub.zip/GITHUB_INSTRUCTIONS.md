# GitHub Connection Instructions

To connect your Replit project to GitHub and update your repository at https://github.com/jfuehrer/DMNPlugin, follow these steps:

## Method 1: Using the Script

1. Open the Replit shell
2. Run the script:
   ```bash
   ./update_github.sh
   ```
3. Follow the prompts to enter your GitHub credentials and commit message

## Method 2: Manual Git Commands

If you prefer to run the commands manually:

1. Configure Git (replace with your information):
   ```bash
   git config --global user.name "Your GitHub Username"
   git config --global user.email "your.email@example.com"
   ```

2. Initialize Git repository (if not already done):
   ```bash
   git init
   ```

3. Add the remote repository:
   ```bash
   git remote add origin https://github.com/jfuehrer/DMNPlugin.git
   ```

4. Add all files:
   ```bash
   git add .
   ```

5. Commit changes:
   ```bash
   git commit -m "Your commit message"
   ```

6. Push to GitHub:
   ```bash
   git push -u origin main
   ```

## GitHub Personal Access Token

You'll need a Personal Access Token instead of your password when pushing to GitHub:

1. Go to GitHub → Settings → Developer Settings → Personal Access Tokens
2. Generate a new token with "repo" permissions
3. Use this token when prompted for a password

## Troubleshooting

If you see "remote already exists" error:
```bash
git remote remove origin
git remote add origin https://github.com/jfuehrer/DMNPlugin.git
```

If your push is rejected due to unrelated histories:
```bash
git pull origin main --allow-unrelated-histories
```

Then resolve any conflicts and try pushing again.