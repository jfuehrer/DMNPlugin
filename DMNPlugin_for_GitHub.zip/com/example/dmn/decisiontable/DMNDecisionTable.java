package com.example.dmn.decisiontable;

<<<<<<< HEAD
import java.util.ArrayList;
import java.util.List;

/**
 * Implementation of DMN Decision Table
 */
public class DMNDecisionTable {
    
    /**
     * Enumeration of DMN Hit Policy types
     */
    public enum HitPolicy {
        UNIQUE("U", "Unique"),
        FIRST("F", "First"),
        PRIORITY("P", "Priority"),
        ANY("A", "Any"),
        COLLECT("C", "Collect"),
        RULE_ORDER("R", "Rule Order"),
        OUTPUT_ORDER("O", "Output Order");
        
        private final String code;
        private final String description;
        
        HitPolicy(String code, String description) {
            this.code = code;
            this.description = description;
        }
        
        public String getCode() {
            return code;
        }
        
        public String getDescription() {
            return description;
        }
    }
    
    private String name;
    private HitPolicy hitPolicy;
    private List<DMNDecisionTableInput> inputs;
    private List<DMNDecisionTableOutput> outputs;
    private List<DMNDecisionTableRule> rules;
    
    /**
     * Constructor
     * 
     * @param name the name of the decision table
     */
    public DMNDecisionTable(String name) {
        this.name = name;
        this.hitPolicy = HitPolicy.UNIQUE; // Default
        this.inputs = new ArrayList<>();
        this.outputs = new ArrayList<>();
        this.rules = new ArrayList<>();
    }
    
    /**
     * Gets the name of the decision table
     * 
     * @return the name
     */
    public String getName() {
        return name;
    }
    
    /**
     * Sets the name of the decision table
     * 
     * @param name the name
     */
    public void setName(String name) {
        this.name = name;
    }
    
    /**
     * Gets the hit policy
     * 
     * @return the hit policy
=======
import com.example.dmn.stereotype.DMNProfile;
import com.example.dmn.stereotype.DMNStereotypes;
import com.nomagic.magicdraw.core.Application;
import com.nomagic.magicdraw.core.Project;
import com.nomagic.magicdraw.openapi.uml.SessionManager;
import com.nomagic.uml2.ext.jmi.helpers.StereotypesHelper;
import com.nomagic.uml2.ext.magicdraw.classes.mdkernel.Class;
import com.nomagic.uml2.ext.magicdraw.classes.mdkernel.Element;
import com.nomagic.uml2.ext.magicdraw.classes.mdkernel.NamedElement;
import com.nomagic.uml2.ext.magicdraw.mdprofiles.Stereotype;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Implementation of a DMN Decision Table.
 * Provides a structure for defining decision tables according to the DMN specification.
 */
public class DMNDecisionTable {
    public enum HitPolicy {
        UNIQUE("U"), FIRST("F"), PRIORITY("P"), ANY("A"), COLLECT("C"), 
        RULE_ORDER("R"), OUTPUT_ORDER("O");
        
        private String symbol;
        
        HitPolicy(String symbol) {
            this.symbol = symbol;
        }
        
        public String getSymbol() {
            return symbol;
        }
    }
    
    public enum AggregationType {
        SUM, MIN, MAX, COUNT
    }
    
    private Element element;
    private DMNProfile dmnProfile;
    private HitPolicy hitPolicy = HitPolicy.UNIQUE;
    private AggregationType aggregation;
    private List<String> inputExpressions = new ArrayList<>();
    private List<String> outputExpressions = new ArrayList<>();
    private List<String> inputValues = new ArrayList<>();
    private List<String> outputValues = new ArrayList<>();
    private List<List<String>> rules = new ArrayList<>();
    
    /**
     * Constructor with existing element.
     * 
     * @param element Existing element with Decision Table stereotype
     */
    public DMNDecisionTable(Element element) {
        this.element = element;
        this.dmnProfile = new DMNProfile();
        this.dmnProfile.init();
        loadFromElement();
    }
    
    /**
     * Create a new DMN Decision Table.
     * 
     * @param project Current project
     * @param name Decision Table name
     * @param owner Owner element (usually a Decision)
     * @return New DMNDecisionTable or null if creation failed
     */
    public static DMNDecisionTable create(Project project, String name, Element owner) {
        if (project == null || name == null || name.trim().isEmpty() || owner == null) {
            return null;
        }
        
        try {
            SessionManager.getInstance().createSession(project, "Create DMN Decision Table");
            
            // Create class to represent decision table
            Class decisionTableClass = project.getElementsFactory().createClassInstance();
            decisionTableClass.setName(name);
            decisionTableClass.setOwner(owner);
            
            // Apply stereotype
            DMNProfile profile = new DMNProfile();
            profile.init();
            profile.applyStereotype(decisionTableClass, DMNStereotypes.DECISION_TABLE);
            
            SessionManager.getInstance().closeSession(project);
            
            return new DMNDecisionTable(decisionTableClass);
        } catch (Exception e) {
            SessionManager.getInstance().cancelSession(project);
            Application.getInstance().getGUILog().showError(
                    "Failed to create DMN Decision Table: " + e.getMessage());
            return null;
        }
    }
    
    /**
     * Load decision table data from the element.
     */
    private void loadFromElement() {
        // Load hit policy
        String hitPolicyStr = (String) dmnProfile.getTaggedValue(
                element, DMNStereotypes.DECISION_TABLE, DMNStereotypes.TAG_HIT_POLICY);
        if (hitPolicyStr != null && !hitPolicyStr.isEmpty()) {
            for (HitPolicy policy : HitPolicy.values()) {
                if (policy.getSymbol().equals(hitPolicyStr)) {
                    hitPolicy = policy;
                    break;
                }
            }
        }
        
        // Load aggregation if any
        String aggregationStr = (String) dmnProfile.getTaggedValue(
                element, DMNStereotypes.DECISION_TABLE, DMNStereotypes.TAG_AGGREGATION);
        if (aggregationStr != null && !aggregationStr.isEmpty()) {
            try {
                aggregation = AggregationType.valueOf(aggregationStr);
            } catch (IllegalArgumentException e) {
                // Ignore invalid value
            }
        }
        
        // Load input expressions
        String inputExprStr = (String) dmnProfile.getTaggedValue(
                element, DMNStereotypes.DECISION_TABLE, DMNStereotypes.TAG_INPUT_EXPRESSIONS);
        if (inputExprStr != null && !inputExprStr.isEmpty()) {
            inputExpressions = Arrays.asList(inputExprStr.split(";"));
        }
        
        // Load output expressions
        String outputExprStr = (String) dmnProfile.getTaggedValue(
                element, DMNStereotypes.DECISION_TABLE, DMNStereotypes.TAG_OUTPUT_VALUES);
        if (outputExprStr != null && !outputExprStr.isEmpty()) {
            outputExpressions = Arrays.asList(outputExprStr.split(";"));
        }
        
        // Load input values
        String inputValuesStr = (String) dmnProfile.getTaggedValue(
                element, DMNStereotypes.DECISION_TABLE, DMNStereotypes.TAG_INPUT_VALUES);
        if (inputValuesStr != null && !inputValuesStr.isEmpty()) {
            inputValues = Arrays.asList(inputValuesStr.split(";"));
        }
        
        // Load output values
        String outputValuesStr = (String) dmnProfile.getTaggedValue(
                element, DMNStereotypes.DECISION_TABLE, DMNStereotypes.TAG_OUTPUT_VALUES);
        if (outputValuesStr != null && !outputValuesStr.isEmpty()) {
            outputValues = Arrays.asList(outputValuesStr.split(";"));
        }
        
        // Load rules
        String rulesStr = (String) dmnProfile.getTaggedValue(
                element, DMNStereotypes.DECISION_TABLE, DMNStereotypes.TAG_RULES);
        if (rulesStr != null && !rulesStr.isEmpty()) {
            String[] ruleLines = rulesStr.split("\n");
            for (String ruleLine : ruleLines) {
                rules.add(Arrays.asList(ruleLine.split(";")));
            }
        }
    }
    
    /**
     * Save decision table data to the element.
     */
    private void saveToElement() {
        Project project = Application.getInstance().getProject();
        
        try {
            SessionManager.getInstance().createSession(project, "Update Decision Table");
            
            // Save hit policy
            dmnProfile.setTaggedValue(
                    element, DMNStereotypes.DECISION_TABLE, DMNStereotypes.TAG_HIT_POLICY, 
                    hitPolicy.getSymbol());
            
            // Save aggregation if any
            if (aggregation != null) {
                dmnProfile.setTaggedValue(
                        element, DMNStereotypes.DECISION_TABLE, DMNStereotypes.TAG_AGGREGATION, 
                        aggregation.name());
            }
            
            // Save input expressions
            dmnProfile.setTaggedValue(
                    element, DMNStereotypes.DECISION_TABLE, DMNStereotypes.TAG_INPUT_EXPRESSIONS, 
                    String.join(";", inputExpressions));
            
            // Save output expressions
            String outputExpressionsStr = String.join(";", outputExpressions);
            dmnProfile.setTaggedValue(
                    element, DMNStereotypes.DECISION_TABLE, DMNStereotypes.TAG_OUTPUT_VALUES, 
                    outputExpressionsStr);
            
            // Save input values
            dmnProfile.setTaggedValue(
                    element, DMNStereotypes.DECISION_TABLE, DMNStereotypes.TAG_INPUT_VALUES, 
                    String.join(";", inputValues));
            
            // Save output values
            dmnProfile.setTaggedValue(
                    element, DMNStereotypes.DECISION_TABLE, DMNStereotypes.TAG_OUTPUT_VALUES, 
                    String.join(";", outputValues));
            
            // Save rules
            StringBuilder rulesStr = new StringBuilder();
            for (List<String> rule : rules) {
                rulesStr.append(String.join(";", rule)).append("\n");
            }
            dmnProfile.setTaggedValue(
                    element, DMNStereotypes.DECISION_TABLE, DMNStereotypes.TAG_RULES, 
                    rulesStr.toString());
            
            SessionManager.getInstance().closeSession(project);
        } catch (Exception e) {
            SessionManager.getInstance().cancelSession(project);
            Application.getInstance().getGUILog().showError(
                    "Failed to save decision table: " + e.getMessage());
        }
    }
    
    /**
     * Get the underlying element.
     * 
     * @return Element representing this decision table
     */
    public Element getElement() {
        return element;
    }
    
    /**
     * Get the decision table name.
     * 
     * @return Decision table name
     */
    public String getName() {
        if (element instanceof NamedElement) {
            return ((NamedElement) element).getName();
        }
        return null;
    }
    
    /**
     * Set the decision table name.
     * 
     * @param name New decision table name
     * @return True if successful, false otherwise
     */
    public boolean setName(String name) {
        if (!(element instanceof NamedElement) || name == null || name.trim().isEmpty()) {
            return false;
        }
        
        Project project = Application.getInstance().getProject();
        try {
            SessionManager.getInstance().createSession(project, "Set Decision Table Name");
            ((NamedElement) element).setName(name);
            SessionManager.getInstance().closeSession(project);
            return true;
        } catch (Exception e) {
            SessionManager.getInstance().cancelSession(project);
            return false;
        }
    }
    
    /**
     * Get the hit policy.
     * 
     * @return Hit policy
>>>>>>> 8b85c5523f88961b2ad4610b2afe9f984215ddb2
     */
    public HitPolicy getHitPolicy() {
        return hitPolicy;
    }
    
    /**
<<<<<<< HEAD
     * Sets the hit policy
     * 
     * @param hitPolicy the hit policy
     */
    public void setHitPolicy(HitPolicy hitPolicy) {
        this.hitPolicy = hitPolicy;
    }
    
    /**
     * Adds an input to the decision table
     * 
     * @param input the input to add
     */
    public void addInput(DMNDecisionTableInput input) {
        inputs.add(input);
    }
    
    /**
     * Adds an output to the decision table
     * 
     * @param output the output to add
     */
    public void addOutput(DMNDecisionTableOutput output) {
        outputs.add(output);
    }
    
    /**
     * Adds a rule to the decision table
     * 
     * @param rule the rule to add
     */
    public void addRule(DMNDecisionTableRule rule) {
        rules.add(rule);
    }
    
    /**
     * Gets all inputs
     * 
     * @return the list of inputs
     */
    public List<DMNDecisionTableInput> getInputs() {
        return inputs;
    }
    
    /**
     * Gets all outputs
     * 
     * @return the list of outputs
     */
    public List<DMNDecisionTableOutput> getOutputs() {
        return outputs;
    }
    
    /**
     * Gets all rules
     * 
     * @return the list of rules
     */
    public List<DMNDecisionTableRule> getRules() {
        return rules;
    }
    
    /**
     * Serializes the decision table to a string representation
     * 
     * @return the string representation
     */
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Decision Table: ").append(name).append("\n");
        sb.append("Hit Policy: ").append(hitPolicy.getCode()).append(" (").append(hitPolicy.getDescription()).append(")\n");
        
        sb.append("\nInputs:\n");
        for (DMNDecisionTableInput input : inputs) {
            sb.append("- ").append(input.getName()).append(" (").append(input.getType()).append(")\n");
        }
        
        sb.append("\nOutputs:\n");
        for (DMNDecisionTableOutput output : outputs) {
            sb.append("- ").append(output.getName()).append(" (").append(output.getType()).append(")\n");
        }
        
        sb.append("\nRules:\n");
        for (int i = 0; i < rules.size(); i++) {
            DMNDecisionTableRule rule = rules.get(i);
            sb.append("Rule #").append(i + 1).append(":\n");
            sb.append("  Inputs: ").append(rule.getInputEntries()).append("\n");
            sb.append("  Outputs: ").append(rule.getOutputEntries()).append("\n");
        }
        
        return sb.toString();
    }
    
    /**
     * Simple inner class for a decision table input
     */
    public static class DMNDecisionTableInput {
        private String name;
        private String type;
        
        public DMNDecisionTableInput(String name, String type) {
            this.name = name;
            this.type = type;
        }
        
        public String getName() {
            return name;
        }
        
        public String getType() {
            return type;
        }
    }
    
    /**
     * Simple inner class for a decision table output
     */
    public static class DMNDecisionTableOutput {
        private String name;
        private String type;
        
        public DMNDecisionTableOutput(String name, String type) {
            this.name = name;
            this.type = type;
        }
        
        public String getName() {
            return name;
        }
        
        public String getType() {
            return type;
        }
    }
    
    /**
     * Simple inner class for a decision table rule
     */
    public static class DMNDecisionTableRule {
        private List<String> inputEntries;
        private List<String> outputEntries;
        
        public DMNDecisionTableRule() {
            this.inputEntries = new ArrayList<>();
            this.outputEntries = new ArrayList<>();
        }
        
        public void addInputEntry(String inputEntry) {
            inputEntries.add(inputEntry);
        }
        
        public void addOutputEntry(String outputEntry) {
            outputEntries.add(outputEntry);
        }
        
        public List<String> getInputEntries() {
            return inputEntries;
        }
        
        public List<String> getOutputEntries() {
            return outputEntries;
        }
    }
}
=======
     * Set the hit policy.
     * 
     * @param hitPolicy New hit policy
     */
    public void setHitPolicy(HitPolicy hitPolicy) {
        this.hitPolicy = hitPolicy;
        saveToElement();
    }
    
    /**
     * Get the aggregation type.
     * 
     * @return Aggregation type or null if not set
     */
    public AggregationType getAggregation() {
        return aggregation;
    }
    
    /**
     * Set the aggregation type.
     * 
     * @param aggregation New aggregation type
     */
    public void setAggregation(AggregationType aggregation) {
        this.aggregation = aggregation;
        saveToElement();
    }
    
    /**
     * Get the input expressions.
     * 
     * @return List of input expressions
     */
    public List<String> getInputExpressions() {
        return new ArrayList<>(inputExpressions);
    }
    
    /**
     * Set the input expressions.
     * 
     * @param inputExpressions New list of input expressions
     */
    public void setInputExpressions(List<String> inputExpressions) {
        this.inputExpressions = new ArrayList<>(inputExpressions);
        saveToElement();
    }
    
    /**
     * Get the output expressions.
     * 
     * @return List of output expressions
     */
    public List<String> getOutputExpressions() {
        return new ArrayList<>(outputExpressions);
    }
    
    /**
     * Set the output expressions.
     * 
     * @param outputExpressions New list of output expressions
     */
    public void setOutputExpressions(List<String> outputExpressions) {
        this.outputExpressions = new ArrayList<>(outputExpressions);
        saveToElement();
    }
    
    /**
     * Get the input values.
     * 
     * @return List of input values
     */
    public List<String> getInputValues() {
        return new ArrayList<>(inputValues);
    }
    
    /**
     * Set the input values.
     * 
     * @param inputValues New list of input values
     */
    public void setInputValues(List<String> inputValues) {
        this.inputValues = new ArrayList<>(inputValues);
        saveToElement();
    }
    
    /**
     * Get the output values.
     * 
     * @return List of output values
     */
    public List<String> getOutputValues() {
        return new ArrayList<>(outputValues);
    }
    
    /**
     * Set the output values.
     * 
     * @param outputValues New list of output values
     */
    public void setOutputValues(List<String> outputValues) {
        this.outputValues = new ArrayList<>(outputValues);
        saveToElement();
    }
    
    /**
     * Get the rules.
     * 
     * @return List of rule lists
     */
    public List<List<String>> getRules() {
        List<List<String>> result = new ArrayList<>();
        for (List<String> rule : rules) {
            result.add(new ArrayList<>(rule));
        }
        return result;
    }
    
    /**
     * Set the rules.
     * 
     * @param rules New list of rule lists
     */
    public void setRules(List<List<String>> rules) {
        this.rules = new ArrayList<>();
        for (List<String> rule : rules) {
            this.rules.add(new ArrayList<>(rule));
        }
        saveToElement();
    }
    
    /**
     * Add a rule to the decision table.
     * 
     * @param rule New rule to add
     */
    public void addRule(List<String> rule) {
        rules.add(new ArrayList<>(rule));
        saveToElement();
    }
    
    /**
     * Remove a rule from the decision table.
     * 
     * @param index Index of the rule to remove
     * @return True if successful, false otherwise
     */
    public boolean removeRule(int index) {
        if (index < 0 || index >= rules.size()) {
            return false;
        }
        
        rules.remove(index);
        saveToElement();
        return true;
    }
}
>>>>>>> 8b85c5523f88961b2ad4610b2afe9f984215ddb2
