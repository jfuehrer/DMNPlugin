package com.example.dmn.ui;

<<<<<<< HEAD
import com.nomagic.magicdraw.core.Application;
import com.nomagic.magicdraw.uml.DiagramTypeConstants;
import com.nomagic.magicdraw.core.Project;

/**
 * Provides customization for DMN diagrams including styling and appearance
 */
public class DMNDiagramCustomization {
    
    private Project project;
    
    /**
     * Default constructor
     */
    public DMNDiagramCustomization() {
        this.project = Application.getInstance().getProject();
    }
    
    /**
     * Initializes diagram customization
     */
    public void initialize() {
        if (project == null) {
            Application.getInstance().getGUILog().log("Warning: Cannot initialize DMN diagram customization - no active project");
            return;
        }
        
        Application.getInstance().getGUILog().log("Initializing DMN diagram customization");
        
        // In a complete implementation, this would register customizations for:
        // - Custom diagram types for DMN
        // - Custom appearance (colors, shapes) for DMN elements
        // - Custom palette for DMN diagrams
    }
    
    /**
     * Disposes resources used by the diagram customization
     */
    public void dispose() {
        // Clean up resources
    }
    
    /**
     * Gets the DMN diagram type ID
     * 
     * @return the diagram type ID
     */
    public String getDMNDiagramType() {
        // In a real implementation, this would return a custom diagram type ID
        // For now, we use a standard diagram type
        return DiagramTypeConstants.UML_CLASS_DIAGRAM;
    }
    
    /**
     * Updates the styling for a DMN element
     * 
     * @param elementID the ID of the element
     * @param stereotypeName the stereotype applied to the element
     */
    public void updateDMNElementStyling(String elementID, String stereotypeName) {
        // This would apply specific styling based on the DMN element type
        // For example:
        // - Decision: rounded rectangle with light blue (#DDEEFF) fill
        // - InputData: rectangle with rounded corners and light green fill
        // - BusinessKnowledgeModel: rectangle with notched corners
        
        Application.getInstance().getGUILog().log("Applying styling for " + stereotypeName + " element");
    }
}
=======
import com.example.dmn.stereotype.DMNStereotypes;
import com.nomagic.magicdraw.core.Application;
import com.nomagic.magicdraw.core.Project;
import com.nomagic.magicdraw.openapi.uml.PresentationElementsManager;
import com.nomagic.magicdraw.openapi.uml.ReadOnlyElementException;
import com.nomagic.magicdraw.openapi.uml.SessionManager;
import com.nomagic.magicdraw.properties.PropertyManager;
import com.nomagic.magicdraw.uml.DiagramTypeConstants;
import com.nomagic.magicdraw.uml.symbols.DiagramPresentationElement;
import com.nomagic.magicdraw.uml.symbols.PresentationElement;
import com.nomagic.magicdraw.uml.symbols.shapes.ShapeElement;
import com.nomagic.uml2.ext.jmi.helpers.StereotypesHelper;
import com.nomagic.uml2.ext.magicdraw.classes.mdkernel.Element;
import com.nomagic.uml2.ext.magicdraw.mdprofiles.Stereotype;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.RenderingHints;
import java.awt.geom.RoundRectangle2D;

/**
 * Customizes the visual appearance of DMN diagrams and elements.
 * Implements the DMN visual style according to the specification.
 */
public class DMNDiagramCustomization {
    private static final int DECISION_ARC_WIDTH = 10;
    private static final int DECISION_ARC_HEIGHT = 10;
    
    /**
     * Initialize diagram customization.
     */
    public void init() {
        // Register diagram customization listeners
        DiagramPresentationElementListener listener = new DiagramPresentationElementListener();
        Application.getInstance().addProjectEventListener(listener);
        
        // Register custom shape handlers
        PresentationElementsManager.getInstance().registerShapeHandler(
                DMNStereotypes.DECISION, new DMNShapeHandler());
        PresentationElementsManager.getInstance().registerShapeHandler(
                DMNStereotypes.INPUT_DATA, new DMNShapeHandler());
        PresentationElementsManager.getInstance().registerShapeHandler(
                DMNStereotypes.BUSINESS_KNOWLEDGE_MODEL, new DMNShapeHandler());
        PresentationElementsManager.getInstance().registerShapeHandler(
                DMNStereotypes.DECISION_SERVICE, new DMNShapeHandler());
        PresentationElementsManager.getInstance().registerShapeHandler(
                DMNStereotypes.KNOWLEDGE_SOURCE, new DMNShapeHandler());
    }
    
    /**
     * Dispose resources.
     */
    public void dispose() {
        // Cleanup if needed
    }
    
    /**
     * Apply styles to elements based on their stereotypes.
     * 
     * @param presentationElement The presentation element to style
     */
    public void applyStyle(PresentationElement presentationElement) {
        if (!(presentationElement instanceof ShapeElement)) {
            return;
        }
        
        ShapeElement shapeElement = (ShapeElement) presentationElement;
        Element element = presentationElement.getElement();
        
        if (element == null) {
            return;
        }
        
        Project project = Application.getInstance().getProject();
        
        try {
            SessionManager.getInstance().createSession(project, "Apply DMN Style");
            
            // Apply style based on stereotype
            if (StereotypesHelper.hasStereotype(element, DMNStereotypes.DECISION)) {
                applyDecisionStyle(shapeElement);
            } else if (StereotypesHelper.hasStereotype(element, DMNStereotypes.INPUT_DATA)) {
                applyInputDataStyle(shapeElement);
            } else if (StereotypesHelper.hasStereotype(element, DMNStereotypes.BUSINESS_KNOWLEDGE_MODEL)) {
                applyBKMStyle(shapeElement);
            } else if (StereotypesHelper.hasStereotype(element, DMNStereotypes.DECISION_SERVICE)) {
                applyDecisionServiceStyle(shapeElement);
            } else if (StereotypesHelper.hasStereotype(element, DMNStereotypes.KNOWLEDGE_SOURCE)) {
                applyKnowledgeSourceStyle(shapeElement);
            }
            
            SessionManager.getInstance().closeSession(project);
        } catch (ReadOnlyElementException e) {
            SessionManager.getInstance().cancelSession(project);
            Application.getInstance().getGUILog().showError(
                    "Failed to apply DMN style: " + e.getMessage());
        }
    }
    
    /**
     * Apply decision style (rounded rectangle with light blue fill).
     * 
     * @param shapeElement Shape element to style
     */
    private void applyDecisionStyle(ShapeElement shapeElement) {
        PropertyManager propertyManager = new PropertyManager();
        propertyManager.setShapeFillColor(shapeElement, Color.decode(DMNStereotypes.DECISION_FILL_COLOR));
        propertyManager.setLineWidth(shapeElement, 1.0f);
        propertyManager.setRoundedRectangleRadius(shapeElement, DECISION_ARC_WIDTH, DECISION_ARC_HEIGHT);
    }
    
    /**
     * Apply input data style.
     * 
     * @param shapeElement Shape element to style
     */
    private void applyInputDataStyle(ShapeElement shapeElement) {
        PropertyManager propertyManager = new PropertyManager();
        propertyManager.setShapeFillColor(shapeElement, Color.decode(DMNStereotypes.INPUT_DATA_FILL_COLOR));
        propertyManager.setLineWidth(shapeElement, 1.0f);
    }
    
    /**
     * Apply business knowledge model style.
     * 
     * @param shapeElement Shape element to style
     */
    private void applyBKMStyle(ShapeElement shapeElement) {
        PropertyManager propertyManager = new PropertyManager();
        propertyManager.setShapeFillColor(shapeElement, Color.decode(DMNStereotypes.BKM_FILL_COLOR));
        propertyManager.setLineWidth(shapeElement, 1.0f);
    }
    
    /**
     * Apply decision service style.
     * 
     * @param shapeElement Shape element to style
     */
    private void applyDecisionServiceStyle(ShapeElement shapeElement) {
        PropertyManager propertyManager = new PropertyManager();
        propertyManager.setShapeFillColor(shapeElement, Color.decode(DMNStereotypes.DECISION_SERVICE_FILL_COLOR));
        propertyManager.setLineWidth(shapeElement, 1.0f);
        propertyManager.setRoundedRectangleRadius(shapeElement, DECISION_ARC_WIDTH, DECISION_ARC_HEIGHT);
    }
    
    /**
     * Apply knowledge source style.
     * 
     * @param shapeElement Shape element to style
     */
    private void applyKnowledgeSourceStyle(ShapeElement shapeElement) {
        PropertyManager propertyManager = new PropertyManager();
        propertyManager.setShapeFillColor(shapeElement, Color.decode(DMNStereotypes.KNOWLEDGE_SOURCE_FILL_COLOR));
        propertyManager.setLineWidth(shapeElement, 1.0f);
    }
    
    /**
     * Apply DMN diagram style.
     * 
     * @param diagram DMN diagram
     */
    public void applyDiagramStyle(DiagramPresentationElement diagram) {
        Project project = Application.getInstance().getProject();
        
        try {
            SessionManager.getInstance().createSession(project, "Apply DMN Diagram Style");
            // Set diagram background, grid, etc.
            diagram.setShowGrid(true);
            diagram.setSnapToGrid(true);
            SessionManager.getInstance().closeSession(project);
        } catch (Exception e) {
            SessionManager.getInstance().cancelSession(project);
            Application.getInstance().getGUILog().showError(
                    "Failed to apply DMN diagram style: " + e.getMessage());
        }
    }
    
    /**
     * Inner class to listen for diagram presentation element changes.
     */
    private class DiagramPresentationElementListener implements com.nomagic.magicdraw.core.ProjectEventListener {
        @Override
        public void diagramOpened(DiagramPresentationElement diagram) {
            if (isDMNDiagram(diagram)) {
                applyDiagramStyle(diagram);
            }
        }
        
        @Override
        public void diagramClosed(DiagramPresentationElement diagram) {
            // Not needed
        }
        
        @Override
        public void elementAdded(Element element) {
            // Not needed
        }
        
        @Override
        public void elementChanged(Element element) {
            // Not needed
        }
        
        @Override
        public void elementRemoved(Element element) {
            // Not needed
        }
        
        /**
         * Check if the diagram is a DMN diagram.
         * 
         * @param diagram Diagram to check
         * @return True if it's a DMN diagram
         */
        private boolean isDMNDiagram(DiagramPresentationElement diagram) {
            Element diagramOwner = diagram.getElement();
            return StereotypesHelper.hasStereotype(diagramOwner, DMNStereotypes.DMN_DIAGRAM);
        }
    }
}
>>>>>>> 8b85c5523f88961b2ad4610b2afe9f984215ddb2
