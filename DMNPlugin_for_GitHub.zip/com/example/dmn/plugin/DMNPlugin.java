package com.example.dmn.plugin;

import com.example.dmn.stereotype.DMNProfile;
import com.example.dmn.ui.DMNDiagramCustomization;
<<<<<<< HEAD

import com.nomagic.magicdraw.core.Application;
import com.nomagic.magicdraw.plugins.Plugin;

/**
 * Main plugin class for the DMN 1.6 plugin
 * This class is the entry point for the CATIA Magic Systems of Systems Architect plugin
 */
public class DMNPlugin extends Plugin {
    
    private DMNProfile dmnProfile;
    private DMNDiagramCustomization dmnDiagramCustomization;
    
    /**
     * Constructor
     * 
     * @param id the plugin ID
     * @param name the plugin name
     */
    public DMNPlugin(String id, String name) {
        super(id, name);
    }
    
    /**
     * Called when the plugin is initialized
     */
    @Override
    public void init() {
        // Initialize the DMN profile with stereotypes
        dmnProfile = new DMNProfile();
        dmnProfile.initialize();
        
        // Initialize diagram customization
        dmnDiagramCustomization = new DMNDiagramCustomization();
        dmnDiagramCustomization.initialize();
        
        // Log initialization
        Application.getInstance().getGUILog().log("DMN Plugin 1.6 initialized successfully.");
    }
    
    /**
     * Called when the plugin is closed
     */
    @Override
    public boolean close() {
        // Clean up profile
=======
import com.example.dmn.ui.DMNPaletteCustomization;
import com.example.dmn.actions.CreateDMNDiagramAction;
import com.nomagic.magicdraw.core.Application;
import com.nomagic.magicdraw.core.Project;
import com.nomagic.magicdraw.plugins.Plugin;
import com.nomagic.magicdraw.plugins.PluginUtilities;
import com.nomagic.magicdraw.ui.actions.MainMenuAction;
import com.nomagic.magicdraw.ui.browser.Tree;
import com.nomagic.magicdraw.ui.browser.actions.DefaultBrowserAction;
import com.nomagic.magicdraw.uml.BaseElement;

import java.util.List;

/**
 * Main plugin class for DMN 1.6 implementation in Magic Systems of Systems Architect.
 * This plugin provides DMN modeling capabilities according to the DMN 1.6 specification.
 */
public class DMNPlugin extends Plugin {
    private DMNProfile dmnProfile;
    private DMNDiagramCustomization diagramCustomization;
    private DMNPaletteCustomization paletteCustomization;
    
    /**
     * Initialize the plugin when it is loaded.
     */
    @Override
    public void init() {
        // Register the DMN profile
        dmnProfile = new DMNProfile();
        dmnProfile.init();
        
        // Initialize diagram customization
        diagramCustomization = new DMNDiagramCustomization();
        diagramCustomization.init();
        
        // Initialize palette customization
        paletteCustomization = new DMNPaletteCustomization();
        paletteCustomization.init();
        
        // Register create DMN diagram action
        MainMenuAction createDiagramAction = new CreateDMNDiagramAction();
        PluginUtilities.registerMainMenuAction(createDiagramAction);
    }
    
    /**
     * Clean up when the plugin is unloaded.
     */
    @Override
    public boolean close() {
        // Clean up resources if needed
>>>>>>> 8b85c5523f88961b2ad4610b2afe9f984215ddb2
        if (dmnProfile != null) {
            dmnProfile.dispose();
        }
        
<<<<<<< HEAD
        // Clean up diagram customization
        if (dmnDiagramCustomization != null) {
            dmnDiagramCustomization.dispose();
        }
        
        // Log shutdown
        Application.getInstance().getGUILog().log("DMN Plugin 1.6 shut down.");
=======
        if (diagramCustomization != null) {
            diagramCustomization.dispose();
        }
        
        if (paletteCustomization != null) {
            paletteCustomization.dispose();
        }
        
>>>>>>> 8b85c5523f88961b2ad4610b2afe9f984215ddb2
        return true;
    }
    
    /**
<<<<<<< HEAD
     * Returns true if the plugin is development mode
     */
    @Override
    public boolean isSupported() {
        return true;
    }
    
    /**
     * Main method for standalone testing
     */
    public static void main(String[] args) {
        System.out.println("DMN Plugin 1.6 for CATIA Magic Systems of Systems Architect 2022x");
        System.out.println("This plugin implements the Decision Model and Notation (DMN) 1.6 specification");
        System.out.println("To use this plugin, it must be installed in Magic Systems of Systems Architect");
    }
}
=======
     * Get the plugin instance.
     * 
     * @return Current plugin instance
     */
    public static DMNPlugin getInstance() {
        return (DMNPlugin) PluginUtilities.getPlugin(DMNPlugin.class.getName());
    }
    
    /**
     * Returns true if the element is a DMN element.
     * 
     * @param element Element to check
     * @return true if the element is a DMN element
     */
    public static boolean isDMNElement(BaseElement element) {
        return element != null && 
               element.getStereotypes().stream()
                   .anyMatch(stereo -> stereo.getName().startsWith("DMN_"));
    }
    
    /**
     * Get the current active project.
     * 
     * @return Current active project
     */
    public static Project getActiveProject() {
        return Application.getInstance().getProject();
    }
}
>>>>>>> 8b85c5523f88961b2ad4610b2afe9f984215ddb2
