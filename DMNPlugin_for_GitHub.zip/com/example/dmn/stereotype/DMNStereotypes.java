package com.example.dmn.stereotype;

/**
<<<<<<< HEAD
 * Constants for DMN stereotypes
 */
public class DMNStereotypes {
    
    // DMN element stereotypes
    public static final String DECISION = "Decision";
    public static final String INPUT_DATA = "InputData";
    public static final String BUSINESS_KNOWLEDGE_MODEL = "BusinessKnowledgeModel";
    public static final String KNOWLEDGE_SOURCE = "KnowledgeSource";
    public static final String DECISION_SERVICE = "DecisionService";
    
    // DMN relationship stereotypes
    public static final String INFORMATION_REQUIREMENT = "InformationRequirement";
    public static final String KNOWLEDGE_REQUIREMENT = "KnowledgeRequirement";
    public static final String AUTHORITY_REQUIREMENT = "AuthorityRequirement";
    
    // DMN artifact stereotypes
    public static final String TEXT_ANNOTATION = "TextAnnotation";
    public static final String ASSOCIATION = "Association";
    
    // DMN special element stereotypes
    public static final String GROUP = "Group";
    
    // DMN decision table stereotypes
    public static final String DECISION_TABLE = "DecisionTable";
    
    private DMNStereotypes() {
        // Private constructor to prevent instantiation
    }
}
=======
 * Constants for DMN stereotypes and their properties.
 * Contains all stereotype names, tag names, and default values used in the plugin.
 */
public class DMNStereotypes {
    // DMN Stereotype names
    public static final String PROFILE_NAME = "DMN_1_6";
    
    // Element stereotypes
    public static final String DECISION = "DMN_Decision";
    public static final String INPUT_DATA = "DMN_InputData";
    public static final String BUSINESS_KNOWLEDGE_MODEL = "DMN_BusinessKnowledgeModel";
    public static final String DECISION_SERVICE = "DMN_DecisionService";
    public static final String KNOWLEDGE_SOURCE = "DMN_KnowledgeSource";
    
    // Requirement stereotypes
    public static final String INFORMATION_REQUIREMENT = "DMN_InformationRequirement";
    public static final String KNOWLEDGE_REQUIREMENT = "DMN_KnowledgeRequirement";
    public static final String AUTHORITY_REQUIREMENT = "DMN_AuthorityRequirement";
    
    // Expression stereotypes
    public static final String DECISION_TABLE = "DMN_DecisionTable";
    public static final String FEEL_EXPRESSION = "DMN_FEELExpression";
    
    // Diagram stereotypes
    public static final String DMN_DIAGRAM = "DMN_Diagram";
    
    // Common tag names
    public static final String TAG_NAME = "name";
    public static final String TAG_DESCRIPTION = "description";
    public static final String TAG_QUESTION = "question";
    public static final String TAG_ALLOWED_ANSWERS = "allowedAnswers";
    
    // Decision table tag names
    public static final String TAG_HIT_POLICY = "hitPolicy";
    public static final String TAG_AGGREGATION = "aggregation";
    public static final String TAG_INPUT_EXPRESSIONS = "inputExpressions";
    public static final String TAG_INPUT_VALUES = "inputValues";
    public static final String TAG_OUTPUT_VALUES = "outputValues";
    public static final String TAG_RULES = "rules";
    
    // Visualization properties
    public static final String DECISION_FILL_COLOR = "#DDEEFF";
    public static final String INPUT_DATA_FILL_COLOR = "#EEFFEE";
    public static final String BKM_FILL_COLOR = "#FFFFDD";
    public static final String DECISION_SERVICE_FILL_COLOR = "#FFDDEE";
    public static final String KNOWLEDGE_SOURCE_FILL_COLOR = "#EEEEEE";
    
    // Prevent instantiation
    private DMNStereotypes() {
    }
}
>>>>>>> 8b85c5523f88961b2ad4610b2afe9f984215ddb2
