package com.example.dmn.stereotype;

import com.nomagic.magicdraw.core.Application;
import com.nomagic.magicdraw.core.Project;
<<<<<<< HEAD
import com.nomagic.magicdraw.uml.Stereotype;
import com.nomagic.uml2.ext.jmi.helpers.StereotypesHelper;
import com.nomagic.uml2.ext.magicdraw.classes.mdkernel.Element;
import com.nomagic.uml2.ext.magicdraw.classes.mdkernel.Package;
import com.nomagic.uml2.ext.magicdraw.mdprofiles.Profile;

/**
 * Provides functionality for the DMN profile which includes all stereotypes
 * needed for DMN 1.6 modeling elements.
 */
public class DMNProfile {
    
    private Project project;
    private Profile dmnProfile;
    
    /**
     * Default constructor
     */
    public DMNProfile() {
        this.project = Application.getInstance().getProject();
    }
    
    /**
     * Initializes the DMN profile
     */
    public void initialize() {
        if (project == null) {
            Application.getInstance().getGUILog().log("Warning: Cannot initialize DMN profile - no active project");
            return;
        }
        
        // Check if profile already exists
        dmnProfile = findDMNProfile();
        
        if (dmnProfile == null) {
            Application.getInstance().getGUILog().log("Creating DMN profile...");
            createDMNProfile();
        } else {
            Application.getInstance().getGUILog().log("DMN profile already exists");
=======
import com.nomagic.magicdraw.openapi.uml.PresentationElementsManager;
import com.nomagic.magicdraw.openapi.uml.ReadOnlyElementException;
import com.nomagic.magicdraw.openapi.uml.SessionManager;
import com.nomagic.magicdraw.uml.Stereotype;
import com.nomagic.uml2.ext.jmi.helpers.StereotypesHelper;
import com.nomagic.uml2.ext.magicdraw.classes.mdkernel.Class;
import com.nomagic.uml2.ext.magicdraw.classes.mdkernel.Element;
import com.nomagic.uml2.ext.magicdraw.classes.mdkernel.Package;
import com.nomagic.uml2.ext.magicdraw.classes.mdkernel.Property;
import com.nomagic.uml2.ext.magicdraw.mdprofiles.Profile;
import com.nomagic.uml2.ext.magicdraw.mdprofiles.Stereotype;
import org.eclipse.emf.common.util.EList;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

/**
 * Creates and manages the DMN profile for the plugin.
 * Handles creation of all stereotypes and their properties according to DMN 1.6 specification.
 */
public class DMNProfile {
    private Profile dmnProfile;
    private Map<String, Stereotype> stereotypes = new HashMap<>();
    
    /**
     * Initialize the DMN profile.
     */
    public void init() {
        Project project = Application.getInstance().getProject();
        if (project == null) {
            return;
        }
        
        // Try to find existing profile first
        dmnProfile = findDMNProfile(project);
        
        // If profile doesn't exist, create it
        if (dmnProfile == null) {
            try {
                SessionManager.getInstance().createSession(project, "Create DMN Profile");
                dmnProfile = createDMNProfile(project);
                createDMNStereotypes(dmnProfile);
                SessionManager.getInstance().closeSession(project);
            } catch (ReadOnlyElementException e) {
                SessionManager.getInstance().cancelSession(project);
                Application.getInstance().getGUILog().showError("Failed to create DMN profile: " + e.getMessage());
            }
        } else {
            // Profile exists, cache stereotypes
            cacheExistingStereotypes();
>>>>>>> 8b85c5523f88961b2ad4610b2afe9f984215ddb2
        }
    }
    
    /**
<<<<<<< HEAD
     * Disposes resources used by the profile
     */
    public void dispose() {
        // Clean up resources
    }
    
    /**
     * Searches for existing DMN profile
     * 
     * @return the profile if found, null otherwise
     */
    private Profile findDMNProfile() {
        for (Profile profile : StereotypesHelper.getProfiles(project)) {
            if (profile.getName().equals("DMN Profile")) {
=======
     * Disposes the profile resources.
     */
    public void dispose() {
        stereotypes.clear();
        dmnProfile = null;
    }
    
    /**
     * Find existing DMN profile in the project.
     * 
     * @param project Current project
     * @return Existing DMN profile or null if not found
     */
    private Profile findDMNProfile(Project project) {
        Collection<Profile> profiles = StereotypesHelper.getProfiles(project);
        for (Profile profile : profiles) {
            if (DMNStereotypes.PROFILE_NAME.equals(profile.getName())) {
>>>>>>> 8b85c5523f88961b2ad4610b2afe9f984215ddb2
                return profile;
            }
        }
        return null;
    }
    
    /**
<<<<<<< HEAD
     * Creates the DMN profile with all stereotypes
     */
    private void createDMNProfile() {
        // This method would create the actual profile in a real implementation
        // For now, we'll just simulate the profile creation
        
        Application.getInstance().getGUILog().log("Creating DMN Profile with stereotypes");
        // In a real implementation, create:
        // - Decision stereotype
        // - InputData stereotype 
        // - BusinessKnowledgeModel stereotype
        // - DecisionService stereotype
        // - KnowledgeSource stereotype
        // - InformationRequirement stereotype
        // - KnowledgeRequirement stereotype
        // - AuthorityRequirement stereotype
    }
    
    /**
     * Applies a stereotype to an element
     * 
     * @param element the element to apply the stereotype to
     * @param stereotypeName the name of the stereotype
     * @return true if successful
     */
    public boolean applyStereotype(Element element, String stereotypeName) {
        if (dmnProfile == null) {
            return false;
        }
        
        Stereotype stereotype = StereotypesHelper.getStereotype(project, stereotypeName, dmnProfile);
        if (stereotype != null) {
            StereotypesHelper.addStereotype(element, stereotype);
            return true;
        }
        return false;
    }
}
=======
     * Create the DMN profile.
     * 
     * @param project Current project
     * @return Newly created DMN profile
     */
    private Profile createDMNProfile(Project project) {
        return StereotypesHelper.createProfile(project, DMNStereotypes.PROFILE_NAME);
    }
    
    /**
     * Create all DMN stereotypes in the profile.
     * 
     * @param profile DMN profile
     */
    private void createDMNStereotypes(Profile profile) {
        Project project = Application.getInstance().getProject();
        
        // Create element stereotypes
        createElementStereotype(project, profile, DMNStereotypes.DECISION, 
                new String[][]{
                    {DMNStereotypes.TAG_NAME, "String"}, 
                    {DMNStereotypes.TAG_QUESTION, "String"}, 
                    {DMNStereotypes.TAG_ALLOWED_ANSWERS, "String"}
                });
        
        createElementStereotype(project, profile, DMNStereotypes.INPUT_DATA, 
                new String[][]{
                    {DMNStereotypes.TAG_NAME, "String"}
                });
        
        createElementStereotype(project, profile, DMNStereotypes.BUSINESS_KNOWLEDGE_MODEL, 
                new String[][]{
                    {DMNStereotypes.TAG_NAME, "String"}
                });
        
        createElementStereotype(project, profile, DMNStereotypes.DECISION_SERVICE, 
                new String[][]{
                    {DMNStereotypes.TAG_NAME, "String"}
                });
        
        createElementStereotype(project, profile, DMNStereotypes.KNOWLEDGE_SOURCE, 
                new String[][]{
                    {DMNStereotypes.TAG_NAME, "String"}
                });
        
        // Create relationship stereotypes
        createRelationshipStereotype(project, profile, DMNStereotypes.INFORMATION_REQUIREMENT);
        createRelationshipStereotype(project, profile, DMNStereotypes.KNOWLEDGE_REQUIREMENT);
        createRelationshipStereotype(project, profile, DMNStereotypes.AUTHORITY_REQUIREMENT);
        
        // Create expression stereotypes
        createElementStereotype(project, profile, DMNStereotypes.DECISION_TABLE, 
                new String[][]{
                    {DMNStereotypes.TAG_HIT_POLICY, "String"}, 
                    {DMNStereotypes.TAG_AGGREGATION, "String"}, 
                    {DMNStereotypes.TAG_INPUT_EXPRESSIONS, "String"}, 
                    {DMNStereotypes.TAG_INPUT_VALUES, "String"}, 
                    {DMNStereotypes.TAG_OUTPUT_VALUES, "String"}, 
                    {DMNStereotypes.TAG_RULES, "String"}
                });
        
        createElementStereotype(project, profile, DMNStereotypes.FEEL_EXPRESSION, 
                new String[][]{
                    {"expression", "String"}
                });
        
        // Create diagram stereotype
        createElementStereotype(project, profile, DMNStereotypes.DMN_DIAGRAM, 
                new String[][]{
                    {DMNStereotypes.TAG_NAME, "String"}
                });
    }
    
    /**
     * Create an element stereotype.
     * 
     * @param project Current project
     * @param profile DMN profile
     * @param name Stereotype name
     * @param properties Array of property name/type pairs
     * @return Created stereotype
     */
    private Stereotype createElementStereotype(Project project, Profile profile, String name, String[][] properties) {
        Stereotype stereotype = StereotypesHelper.createStereotype(project, name, profile);
        
        // Add properties (tags)
        if (properties != null) {
            for (String[] property : properties) {
                StereotypesHelper.createTagDefinition(project, property[0], property[1], stereotype);
            }
        }
        
        stereotypes.put(name, stereotype);
        return stereotype;
    }
    
    /**
     * Create a relationship stereotype.
     * 
     * @param project Current project
     * @param profile DMN profile
     * @param name Stereotype name
     * @return Created stereotype
     */
    private Stereotype createRelationshipStereotype(Project project, Profile profile, String name) {
        Stereotype stereotype = StereotypesHelper.createStereotype(project, name, profile);
        stereotype.setIsAbstract(false);
        stereotypes.put(name, stereotype);
        return stereotype;
    }
    
    /**
     * Cache all existing stereotypes from the profile.
     */
    private void cacheExistingStereotypes() {
        Project project = Application.getInstance().getProject();
        
        // Cache all stereotypes for quick access
        Collection<Stereotype> allStereotypes = StereotypesHelper.getStereotypes(project);
        for (Stereotype stereotype : allStereotypes) {
            if (stereotype.getOwner() == dmnProfile) {
                stereotypes.put(stereotype.getName(), stereotype);
            }
        }
    }
    
    /**
     * Get a stereotype by name.
     * 
     * @param name Stereotype name
     * @return Stereotype or null if not found
     */
    public Stereotype getStereotype(String name) {
        return stereotypes.get(name);
    }
    
    /**
     * Apply a stereotype to an element.
     * 
     * @param element Element to which the stereotype will be applied
     * @param stereotypeName Name of the stereotype to apply
     * @return True if successful, false otherwise
     */
    public boolean applyStereotype(Element element, String stereotypeName) {
        Project project = Application.getInstance().getProject();
        Stereotype stereotype = getStereotype(stereotypeName);
        
        if (stereotype == null) {
            return false;
        }
        
        try {
            SessionManager.getInstance().createSession(project, "Apply " + stereotypeName);
            StereotypesHelper.applyStereotype(element, stereotype);
            SessionManager.getInstance().closeSession(project);
            return true;
        } catch (Exception e) {
            SessionManager.getInstance().cancelSession(project);
            Application.getInstance().getGUILog().showError(
                    "Failed to apply stereotype " + stereotypeName + ": " + e.getMessage());
            return false;
        }
    }
    
    /**
     * Set a tagged value on an element.
     * 
     * @param element Element with the stereotype
     * @param stereotypeName Name of the stereotype
     * @param tagName Name of the tag
     * @param value Value to set
     * @return True if successful, false otherwise
     */
    public boolean setTaggedValue(Element element, String stereotypeName, String tagName, Object value) {
        Project project = Application.getInstance().getProject();
        Stereotype stereotype = getStereotype(stereotypeName);
        
        if (stereotype == null || !StereotypesHelper.hasStereotype(element, stereotype)) {
            return false;
        }
        
        try {
            SessionManager.getInstance().createSession(project, "Set tagged value");
            StereotypesHelper.setStereotypePropertyValue(element, stereotype, tagName, value);
            SessionManager.getInstance().closeSession(project);
            return true;
        } catch (Exception e) {
            SessionManager.getInstance().cancelSession(project);
            Application.getInstance().getGUILog().showError(
                    "Failed to set tagged value " + tagName + ": " + e.getMessage());
            return false;
        }
    }
    
    /**
     * Get a tagged value from an element.
     * 
     * @param element Element with the stereotype
     * @param stereotypeName Name of the stereotype
     * @param tagName Name of the tag
     * @return Value of the tag or null if not found
     */
    public Object getTaggedValue(Element element, String stereotypeName, String tagName) {
        Stereotype stereotype = getStereotype(stereotypeName);
        
        if (stereotype == null || !StereotypesHelper.hasStereotype(element, stereotype)) {
            return null;
        }
        
        return StereotypesHelper.getStereotypePropertyValue(element, stereotype, tagName);
    }
    
    /**
     * Get the DMN profile.
     * 
     * @return DMN profile
     */
    public Profile getDMNProfile() {
        return dmnProfile;
    }
}
>>>>>>> 8b85c5523f88961b2ad4610b2afe9f984215ddb2
