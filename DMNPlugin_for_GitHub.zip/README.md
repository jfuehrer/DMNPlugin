# DMN Plugin for Magic Systems of Systems Architect 2022x

## Overview

This plugin implements the Decision Model and Notation (DMN) 1.6 specification for CATIA Magic Systems of Systems Architect 2022x. It provides modeling elements, stereotypes, and diagram customization to enable full DMN modeling capabilities within the Magic Systems environment.

## Features

- Full implementation of DMN 1.6 specification elements:
  - Decision
  - Input Data
  - Business Knowledge Model
  - Decision Service
  - Knowledge Source
  - Information Requirement
  - Knowledge Requirement
  - Authority Requirement
- Custom DMN diagrams with specialized notation
- DMN-specific palette with all DMN elements
- Decision table implementation with full hit policy support
- FEEL expression language support for decision logic
- Automatic stereotype application to UML/SysML elements
- Custom styling for DMN elements (e.g., Decision nodes as rounded rectangles with light blue background)

## Installation

### Prerequisites

- Magic Systems of Systems Architect 2022x or later
- JDK 1.8 or later

### Installation Steps

1. Download the DMN plugin package (`DMN_Plugin.zip`)
2. Open Magic Systems of Systems Architect
3. Navigate to "Options" → "Resource/Plugin Manager"
4. Click on "Import..." and select the downloaded `DMN_Plugin.zip` file
5. Restart Magic Systems of Systems Architect

For detailed installation instructions, please refer to the [INSTALLATION_GUIDE.md](INSTALLATION_GUIDE.md) file.

## Usage

After installation, you can access DMN elements through:

1. **DMN Diagram Creation**: Right-click in the Project Browser → "Create Diagram" → "DMN Diagram"
2. **DMN Palette**: The palette in DMN diagrams will display all DMN modeling elements
3. **DMN Toolbox**: Access the DMN toolbox from the main menu → "Tools" → "DMN"

For detailed usage instructions and information about the DMN specification implementation, please refer to the [DMN_SPECIFICATION_IMPLEMENTATION.md](DMN_SPECIFICATION_IMPLEMENTATION.md) file.

## Development

This plugin is developed as an extension to Magic Systems of Systems Architect using the provided API.

### Building from Source

<<<<<<< HEAD
1. Set the MAGICSYSTEMS_HOME environment variable to point to your Magic Systems installation directory (e.g., `C:\Program Files\Magic Systems of Systems Architect`)
=======
1. Set the MAGICSYSTEMS_HOME environment variable to point to your Magic Systems installation directory
>>>>>>> 8b85c5523f88961b2ad4610b2afe9f984215ddb2
2. Run the build script:
   - Windows: `build.bat`
   - Linux/Mac: `./build.sh`
3. The built plugin will be available in the `dist/DMN_Plugin` directory

## License

<<<<<<< HEAD
Copyright (c) 2025 Example Company. All rights reserved.
=======
Copyright (c) 2025. All rights reserved.
>>>>>>> 8b85c5523f88961b2ad4610b2afe9f984215ddb2

## Contact

For support, questions, or feedback, please contact:
<<<<<<< HEAD
- Email: support@example.com
- Website: https://www.example.com
=======
>>>>>>> 8b85c5523f88961b2ad4610b2afe9f984215ddb2
