#!/bin/bash

# This script helps push code to GitHub
# Make sure you have set up a Personal Access Token before running this script

# Configure Git (replace with your actual information)
git config --global user.name "Your GitHub Username"
git config --global user.email "your.email@example.com"

# Initialize Git repository if not already initialized
if [ ! -d .git ]; then
  echo "Initializing Git repository..."
  git init
  echo "Git repository initialized."
fi

# Add the remote repository
echo "Setting up remote repository..."
git remote remove origin 2>/dev/null
git remote add origin https://github.com/jfuehrer/DMNPlugin.git
echo "Remote repository configured."

# Check if we need to pull first
echo "Checking remote repository status..."
if git ls-remote --exit-code origin &>/dev/null; then
  echo "Remote repository exists. Pulling first..."
  git pull origin main --allow-unrelated-histories
fi

# Add all files
echo "Adding files to Git..."
git add .

# Commit changes
echo "Committing changes..."
read -p "Enter commit message: " message
git commit -m "$message"

# Push to GitHub (this will prompt for your GitHub username and Personal Access Token)
echo "Pushing to GitHub..."
echo "You will be prompted for your GitHub username and Personal Access Token (not your password)."
git push -u origin main

echo "Process completed. Please check your GitHub repository at https://github.com/jfuehrer/DMNPlugin to confirm changes."